/* Manually created file that is not synchronized by the update_ortp.sh script. */
/* Use the config header created for mediastreamer */

#include "../../mediastreamer-config.h"
