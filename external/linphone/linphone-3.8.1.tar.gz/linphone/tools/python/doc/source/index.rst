.. Linphone documentation master file, created by
   sphinx-quickstart on Wed Aug 20 15:37:38 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Linphone for Python documentation
=================================

.. toctree::
   :maxdepth: 2
   :numbered:

   getting_started
   api_reference


Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`

