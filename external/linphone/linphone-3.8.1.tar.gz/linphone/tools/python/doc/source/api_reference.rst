API reference
=============

Enums
-----

.. include:: enums.rst

Classes
-------

.. container:: custom-index

   .. raw:: html

      <script type="text/javascript" src='_static/pylinphone.js'></script>

.. currentmodule:: linphone

.. automodule:: linphone
   :members:
   :undoc-members:

.. autoattribute:: linphone.__version__
